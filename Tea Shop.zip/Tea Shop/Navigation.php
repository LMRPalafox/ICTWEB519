<html>

<head>
   
<link rel="stylesheet" type="text/css" href="../Tea Shop/CSS/Header.css">
<title>Novel Tea</title>
</head>

<body>

<div class="header">
    
<div class="headerleft">
<a href="http://localhost/tea%20shop/IndexPlayground.php"><img src="../Tea Shop/Resources/Logo.PNG"></a>
</div>

<div class="headerright">
<strong class="Header1"> <b>Novel Tea</b> </strong> </br>
<strong class="Header2"> Novelty Tea Items <strong>
</div>

</div>

<div class="navigation">
<div class="navbar">
  
  <div class="dropdown">
    <button class="dropbtn"><a href="http://localhost/tea%20shop/IndexPlayground.php">Home</a> 
      <i class="fa fa-caret-down"></i>
    </button>
 </div>

  <!-- About Us Drop Donw -->
  <div class="dropdown">
    <button class="dropbtn"><a href="Services.php">Services</a> 
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <div class="dropdown2">
            <button class="dropbtn2"> Products
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content2">
              <a href="Coffee.php">Organic Coffee</a>
              <a href="Tea.php">Premium Tea</a>
              <a href="Cookie.php">Fancy Cookies</a>
            </div>     
        </div>
     </div>
  </div>

  <!-- About Us Drop Donw -->
  <div class="dropdown">
    <button class="dropbtn"><a href="Contact US.php">About Us </a>
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="Contact US.php">Contact Us</a>
      <a href="Contact US.php">About Our Company</a>
      <a href="Contact US.php">Management Team</a>
      <div class="dropdown2">
            <button class="dropbtn2">Careers
            <i class="fa fa-caret-down"></i>
            </button>
            <div class="dropdown-content2">
              <a href="Jobs.php">Driver</a>
              <a href="Jobs.php">Cook</a>
              <a href="Jobs.php">Baker</a>
            </div>     
        </div>
     </div>
  </div>

</div>
</div>

</body>


</html>