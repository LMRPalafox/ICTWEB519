<html>

<head>
   
<link rel="stylesheet" type="text/css" href="../Tea Shop/CSS/Services.css">


<title>Novel Tea</title>



</head>

<body>
<?php include('Navigation.php')?>


<div class="Services">
    <strong class="HeaderS1">Who We Are</strong>
    
     <div class="BodyLeft">
     <img src="../Tea Shop/Resources/Logo.PNG">      
     </div> 
        
     <div class="BodyRight">
        <span class="MainText"> We are a Dedicated Organization keen on making sure that our
                                products are up to our high standards and arrive at your doorsteps to enjoy at the comfort of your home.
                                Ideal to have while reading a favourtie novel or spending time with your loved ones.
                                From our humble bakery at NSW Australia, we Pride ourselves on our
                                Tasty Treats and Passion oozing in every bite or sip of our products since 2021.
                                Founded by Luis Palafox, a book lover who is also a hard worker and a full-time full stack developer by day.
        </span>      
     </div>

   </div>

<div class="Product">
<div class = "Query">
            <h2>Our Management</h2>
                <div class="table-responsive">
                <table frame="lhs" class="table">
                <tr>
                <th  class="EMPID">EMPLOYEE ID</th>
                <th  class="POSITION">POSITION</th>
                <th  class="FIRSTNAME">FIRST NAME</th>
                <th  class="LASTNAME">LAST NAME</th>
                <th  class="EMAIL">EMAIL</th>
                <th  class="REG_DATE">REGISTERED DATE</th>
                </tr>
                <?php
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "NOVELTEA";
                $con = mysqli_connect($servername, $username, $password, $dbname);
                if(mysqli_connect_errno()){
                echo "Failed to connect to MYSQL: ".mysqli_connect_error();
                }
                $sql = "SELECT  `EMPID`,
                                `POSITION`,
                                `FIRSTNAME`,
                                `LASTNAME`,
                                `EMAIL`,
                                `REG_DATE`
                        FROM `MANAGEMENT` 
                        ORDER BY EMPID ASC";
                $result1 = $con->query($sql);

                    if(!empty($result1))
                    {
                        $total = 0;
                        foreach($result1 as $keys => $values)
                        {
                            ?>
                            <tr>
                            <td><?php echo $values["EMPID"]; ?></td>
                            <td><?php echo $values["POSITION"]; ?></td>
                            <td><?php echo $values["FIRSTNAME"]; ?></td>
                            <td><?php echo $values["LASTNAME"]; ?></td>
                            <td><?php echo $values["EMAIL"]; ?></td>
                            <td><?php echo $values["REG_DATE"]; ?></td>
                            </tr>
                            <?php 
                        }
                        $con->close();
                    }  
                        ?>
                        
                    </table>
</div>
<div class="footer">
    
  <p><b>Contact us:</b>
  <br>
  <img src="/Book Market/FILES/gmail.png"> NovelTea@Gmail.com
  <br>
  <img src="/Book Market/FILES/Facebook.png"> NovelTea
  <br>
  <img src="/Book Market/FILES/Twitter.png"> @Noveltea
  </p>
  <p class="Middle"> All Products Served are Guaranteed Fresh.</p>

</div>
</body>

</html>