<html>

<head>
   
<link rel="stylesheet" type="text/css" href="../Tea Shop/CSS/Services.css">


<title>Novel Tea</title>



</head>

<body>
<?php include('Navigation.php')?>


<div class="Services">
    <strong class="HeaderS1">Join our Team! We would love to have you aboard soon!</strong>
    
     <div class="BodyLeft">
     <img src="../Tea Shop/Resources/Logo.PNG">      
     </div> 
        
     <div class="BodyRight">
        <span class="MainText"> We are currently Under the Process of expanding our business
                                Expect to have Job Opportunities soon.
        </span>      
     </div>

     
   </div>

   <div class="Product">
<div class = "Query">
            <h2>Job Bulletin</h2>
                <div class="table-responsive">
                <table frame="lhs" class="table">
                <tr>
                <th  class="EMPID">JOB ID</th>
                <th  class="POSITION">POSITION</th>
                <th  class="FIRSTNAME">REQUIREMENTS</th>
                <th  class="EMAIL">RECRUITER EMAIL</th>
                <th  class="REG_DATE">REGISTERED DATE</th>
                </tr>
                <?php
                
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "NOVELTEA";
                $con = mysqli_connect($servername, $username, $password, $dbname);
                if(mysqli_connect_errno()){
                echo "Failed to connect to MYSQL: ".mysqli_connect_error();
                }
                $sql = "SELECT  `JOBID`,
                                `POSITION`,
                                `REQUIREMENTS`,
                                `RECRUITEREMAIL`,
                                `REG_DATE`
                        FROM `JOBS` 
                        ORDER BY JOBID ASC";
                $result1 = $con->query($sql);

                    if(!empty($result1))
                    {
                        $total = 0;
                        foreach($result1 as $keys => $values)
                        {
                            ?>
                            <tr>
                            <td><?php echo $values["JOBID"]; ?></td>
                            <td><?php echo $values["POSITION"]; ?></td>
                            <td><?php echo $values["REQUIREMENTS"]; ?></td>
                            <td><?php echo $values["RECRUITEREMAIL"]; ?></td>
                            <td><?php echo $values["REG_DATE"]; ?></td>
                            </tr>
                            <?php 
                        }
                        $con->close();
                    }  
                        ?>
                        
                    </table>
</div>

</Body>
</html>