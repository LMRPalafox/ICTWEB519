<html>

<head>
   
<link rel="stylesheet" type="text/css" href="../Tea Shop/CSS/Services.css">


<title>Novel Tea</title>



</head>

<body>

<?php include('Navigation.php')?>

   <!-- body  -->
   <div class="Product">
   <strong class="HeaderS1">Sweet Treats!</strong>
     <div class="Row">
       
       
       <?php
          //setup pagination
          if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
            } else {
            $pageno = 1;
            }
      
           //formula for pagination
           $no_of_records_per_page = 9;
           $offset = ($pageno-1) * $no_of_records_per_page; 
             $chosenbooks = array();
             $con = mysqli_connect("localhost","root","","NOVELTEA");
             if(mysqli_connect_errno()){
             echo "Failed to connect to MYSQL: ".mysqli_connect_error();
             }
               //get number of pages
                $total_pages_sql = "SELECT COUNT(*) FROM product";
                $result = mysqli_query($con,$total_pages_sql);
                $total_rows = mysqli_fetch_array($result)[0];
                $total_pages = ceil($total_rows / $no_of_records_per_page);
                $chosenbooks = array();

         
         $chosenbooks = array();
         $con = mysqli_connect("localhost","root","","NOVELTEA");
         if(mysqli_connect_errno()){
         echo "Failed to connect to MYSQL: ".mysqli_connect_error();
         }
         $sql = "SELECT DRINKID, DRINK_NAME, DRINK_TYPE, DESCRIPTION, PRICE, IMAGES, STRENGTH 
                 FROM PRODUCT
                 WHERE DRINK_TYPE = 'PASTRY'
                 ORDER BY DRINKID
                 LIMIT $offset, $no_of_records_per_page";
         $result1 = $con->query($sql);
        
         if ($result1->num_rows >0){
            //output each row
         while($row = $result1->fetch_assoc()){
         echo '<div class="column">';
         //echo '<a href="PHP/SingleBookPage.php">';
         echo '<form action= "" method="GET">';
         echo '<input type="hidden"  id="teaid" name="teaid" value="'.$row['DRINKID'].'">';
         echo '<input type = "image" src="data:image/png;base64,'.base64_encode($row['IMAGES']).'" class= "Featured"/>';
         echo '</form>';
         //echo '</a>';
         echo '<p class="TeaDescription">'. $row['DRINK_NAME']. '<br><br>';
         echo '<p class="TeaHeader"> Beverage Type:</p>';
         echo '<p class="TeaDescription">'. $row['DRINK_TYPE']. '<br><br>';
         echo '<p class="TeaHeader">Description:</p>';
         echo '<p class="TeaDescription">'. $row['DESCRIPTION']. '<br>';
         echo '<br>';
         echo '<p class="TeaHeader"> Flavour: </p>';
         echo '<p class="TeaDescription"><b>'. $row['STRENGTH']. '<br>';
         echo  '<p class="TeaDescription">$'.$row['PRICE']. '</b></p>';
         echo '<input type="hidden" name="hidden_price" value="'.$row['PRICE'].'">';
         echo '<input type="hidden" name="quantity" value= 1>';
         echo '<input type="submit" style="border:none;margin-top:5px;background-color:#7E8D85;" name="add"  data-wrapper-class="purchasebutton" value="Add to Cart">';
         echo '</form>';
         echo '</div>'; 
         
         //echo $row['BOOKID'];
         //$chosenbooks[] = $row['BOOKID'];
         //$testchosenbooks = $_POST['bookid']; 
         //$_SESSION ['display'] = $testchosenbooks;//$chosenbooks;
        }
         }
        else{
            echo "No Available Books.";
        }

        
        //$testchosenbooks = $_GET["bookid"];
        //$_SESSION ['display'] = $testchosenbooks;
        $con->close(); 
       //print_r($_SESSION);  
         ?> 

    </div>

</body>

<ul class="pagination">
        <li><a href="?pageno=1">First</a></li>
        <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">&nbsp Prev &nbsp</a>
        </li>
        <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">
            <a href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">&nbsp Next &nbsp</a>
        </li>
        <li><a href="?pageno=<?php echo $total_pages; ?>">&nbsp Last &nbsp</a></li>
    </ul>

</html>